===============================================================================
E.ON INNOVATION CHALLENGE 2026 // PROBLEM STATEMENT 2: IT SECURITY
SUBMISSION PACKAGE FOR CLUSTER 4 & CLUSTER 5
===============================================================================

PROJECT NAME: GridShield AI
AUTHORS: Pulkit Agrawal (Lead AI Engineer) & Kabir Roy (Cybersecurity Lead)
LIVE PRODUCTION URL: https://e-on-project.vercel.app/
GITHUB REPOSITORY: https://github.com/Kabirroy12345/E.ON-Project (Branch: v2-global-edition)

SELECTED CLUSTERS:
1. Cluster 4: IT Security - Improvement of protection systems
   - Folder: Cluster_4_IT_Security_Protection_Systems/
   - Focus: Autonomous Purple Team SOC, Red vs Blue AI Loop, GraphSAGE 2-hop GNN (<140ms),
            January 2026 Berlin Cable Bridge Sabotage mitigation in <1.83s.

2. Cluster 5: IT Security - Protection schemes for customer-based assets
   - Folder: Cluster_5_IT_Security_Customer_Asset_Protection/
   - Focus: Decentralized 1.14ms TinyML on Cortex-M4 (<800KB flash, 118KB RAM), 100% GDPR
            zero-leakage, 4-pillar customer incentive model (4-8% tariff rebate, 25% insurance).

3. Master Deliverables:
   - Folder: Master_Deliverables_and_Verification/
   - Contains Complete 12-slide Pitch Deck, 24-page Visual Evidence Dossier, and 5-min Script.
===============================================================================
